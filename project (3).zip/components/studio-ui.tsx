"use client";
import { createContext, useContext, useEffect, useRef } from "react";
import {
  LayoutDashboard,
  BookOpen,
  PanelsTopLeft,
  UsersRound,
  Network,
  MapPin,
  Globe2,
  Waypoints,
  FlaskConical,
  GitBranch,
  LibraryBig,
  ShieldCheck,
  NotebookPen,
  Images,
  ChartNoAxesCombined,
  Settings2,
  X,
  Feather,
} from "lucide-react";
import { Project, Entry } from "@/lib/studio";
export const icons: Record<string, typeof Feather> = {
  overview: LayoutDashboard,
  manuscript: BookOpen,
  chapters: PanelsTopLeft,
  characters: UsersRound,
  relationships: Network,
  locations: MapPin,
  worldbuilding: Globe2,
  timeline: Waypoints,
  stem: FlaskConical,
  "story-arcs": GitBranch,
  research: LibraryBig,
  continuity: ShieldCheck,
  notes: NotebookPen,
  media: Images,
  analytics: ChartNoAxesCombined,
  settings: Settings2,
};
interface Store {
  p: Project;
  set: (fn: (p: Project) => Project) => void;
  nav: (s: string) => void;
  edit: (e: Entry) => void;
  create: (k: string) => void;
  open: (e: Entry) => void;
  save: (e: Entry, quiet?: boolean) => void;
  remove: (e: Entry) => void;
  notice: (s: string) => void;
  confirm: (s: string, fn: () => void) => void;
}
export const StudioContext = createContext<Store>(null!);
export const useStudio = () => useContext(StudioContext);
export function Icon({ k, size = 17 }: { k: string; size?: number }) {
  const I = icons[k] || Feather;
  return <I size={size} strokeWidth={1.6} />;
}
export function Modal({
  title,
  close,
  children,
}: {
  title: string;
  close: () => void;
  children: React.ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    d?.showModal();
    return () => d?.close();
  }, []);
  return (
    <dialog
      ref={ref}
      onCancel={close}
      onClick={(e) => {
        if (e.target === ref.current) close();
      }}
      aria-label={title}
    >
      <div className="dialoghead">
        <h2>{title}</h2>
        <button className="iconbtn" onClick={close} aria-label="Close dialog">
          <X />
        </button>
      </div>
      {children}
    </dialog>
  );
}
export function PageHead({
  eyebrow,
  title,
  sub,
  children,
}: {
  eyebrow: string;
  title: string;
  sub: string;
  children?: React.ReactNode;
}) {
  return (
    <header className="pagehead">
      <div>
        <small className="eyebrow">{eyebrow}</small>
        <h1>{title}</h1>
        <p>{sub}</p>
      </div>
      {children}
    </header>
  );
}
export function Meter({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color?: string;
}) {
  const n = Math.min(100, Math.max(0, Math.round(value) || 0));
  return (
    <div className="meter">
      <div>
        <span>{label}</span>
        <span>{n}%</span>
      </div>
      <progress
        value={n}
        max={100}
        aria-label={label}
        style={{ "--bar": color || "var(--moss)" } as React.CSSProperties}
      />
    </div>
  );
}
