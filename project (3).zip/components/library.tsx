"use client";
import { useState } from "react";
import { labels, singular, Entry, getImage, empty } from "@/lib/studio";
import { useStudio, PageHead, Icon, Meter } from "./studio-ui";
import { ArrowUpRight, Plus, Pin, Check, GitBranch } from "lucide-react";
const intros: Record<string, string> = {
  characters:
    "The lives, instincts, and attachments at the heart of the novel.",
  relationships:
    "Trace the bonds of attachment, trust, and conflict across the cast.",
  locations: "A field guide to the places that shape the story.",
  worldbuilding: "The ecology, systems, and routines of Monkey Mountain.",
  timeline: "Follow story chronology independently of manuscript order.",
  stem: "Ground Punch’s discoveries in observable, believable science.",
  "story-arcs": "Follow each thread from its first scene to its resolution.",
  research: "A working collection of clearly marked mock research notes.",
  continuity:
    "Review story facts and resolve contradictions in the active timeline.",
  notes: "Keep a home for fragments, scene ideas, and questions.",
  media: "A visual notebook of places, characters, and atmosphere.",
};
export default function Library({ kind }: { kind: string }) {
  const { p, set, open, save, create, notice } = useStudio(),
    [q, Q] = useState(""),
    [filter, F] = useState(""),
    [status, S] = useState(""),
    [extra, E] = useState("");
  const all = p.entries.filter((x) => x.kind === kind),
    list = all
      .filter(
        (e) =>
          (!filter || e.category === filter) &&
          (!status ? e.status !== "Archived" : e.status === status) &&
          (!extra || Object.values(e.meta).some((v) => v.includes(extra))) &&
          (e.title + " " + e.summary).toLowerCase().includes(q.toLowerCase()),
      )
      .sort((a, b) =>
        kind === "timeline"
          ? Number(a.meta.Sequence) - Number(b.meta.Sequence)
          : Number(b.meta.Pinned === "yes") - Number(a.meta.Pinned === "yes"),
      );
  const issues = all.filter((x) => x.status === "Open");
  function run() {
    const cs = p.entries.filter((x) => x.kind === "chapters"),
      rules = cs.filter((e) =>
        (
          p.rules || ["Kuro died", "Kuro is dead", "Punch solved an equation"]
        ).some(
          (rule) =>
            rule.trim() &&
            e.content.toLowerCase().includes(rule.trim().toLowerCase()),
        ),
      );
    const found = rules
      .filter((c) => !all.some((i) => i.meta.Source === c.id))
      .map((c) => ({
        ...empty("continuity"),
        id: crypto.randomUUID(),
        title: "Review story fact: " + c.title,
        summary:
          "A manuscript statement needs review against the established story facts.",
        category: "Story facts",
        meta: { Source: c.id, Severity: "High", Chapters: String(c.number) },
      }));
    set((v) => ({ ...v, entries: [...v.entries, ...found] }));
    notice(`${cs.length} chapters checked · ${found.length} new issues`);
  }
  return (
    <>
      <PageHead
        eyebrow={
          [
            "characters",
            "relationships",
            "locations",
            "worldbuilding",
            "story-arcs",
            "timeline",
          ].includes(kind)
            ? "STORY BIBLE"
            : "STUDIO TOOLS"
        }
        title={labels[kind]}
        sub={intros[kind]}
      >
        <button className="goldbtn" onClick={() => create(kind)}>
          <Plus />
          New {singular[kind]?.toLowerCase()}
        </button>
      </PageHead>
      {kind === "timeline" && (
        <div className="callout">Active timeline · {p.active}</div>
      )}
      {kind === "continuity" && (
        <div className="callout between">
          <div>
            <strong>{issues.length} open issues</strong>
            <p>
              Resolution score:{" "}
              {Math.round(
                ((all.length - issues.length) / (all.length || 1)) * 100,
              )}
              % · A review indicator, not a measure of literary quality.
            </p>
          </div>
          <button onClick={run}>Run rule checks</button>
        </div>
      )}
      {kind === "continuity" && (
        <details className="panel setting">
          <summary>Edit continuity rules</summary>
          <p>
            Flag chapters containing any of these phrases, one per line. Checks
            are literal matches, not AI analysis.
          </p>
          <label>
            Flagged phrases
            <textarea
              rows={4}
              value={(
                p.rules || [
                  "Kuro died",
                  "Kuro is dead",
                  "Punch solved an equation",
                ]
              ).join("\n")}
              onChange={(e) =>
                set((v) => ({ ...v, rules: e.target.value.split("\n") }))
              }
            />
          </label>
        </details>
      )}
      {kind === "stem" && (
        <div className="panel coverage">
          <h3>Concept coverage</h3>
          {[...new Set(all.map((x) => x.category))].map((c) => (
            <Meter
              key={c}
              label={c}
              value={
                (all.filter((x) => x.category === c).length / all.length) * 100
              }
            />
          ))}
        </div>
      )}
      <div className="tools">
        <input
          aria-label="Search library"
          placeholder={"Search " + labels[kind]?.toLowerCase() + "…"}
          value={q}
          onChange={(e) => Q(e.target.value)}
        />
        <select
          aria-label="Filter category"
          value={filter}
          onChange={(e) => F(e.target.value)}
        >
          <option value="">All categories</option>
          {[...new Set(all.map((x) => x.category).filter(Boolean))].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <select
          aria-label="Filter status"
          value={status}
          onChange={(e) => S(e.target.value)}
        >
          <option value="">All current statuses</option>
          {[...new Set(all.map((x) => x.status))].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        {["timeline", "continuity"].includes(kind) && (
          <select
            aria-label="Filter by detail"
            value={extra}
            onChange={(e) => E(e.target.value)}
          >
            <option value="">
              {kind === "timeline" ? "All eras & references" : "All severities"}
            </option>
            {[
              ...new Set(
                all
                  .flatMap((x) =>
                    kind === "timeline"
                      ? [x.meta.Era, x.meta.Characters, x.meta.Locations]
                      : [x.meta.Severity],
                  )
                  .filter(Boolean),
              ),
            ].map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        )}
      </div>
      <p className="listcount">
        {list.length} {kind === "characters" ? "CAST MEMBERS" : "RECORDS"}
      </p>
      {!list.length ? (
        <div className="empty">
          No records match. Change the filters or add a new{" "}
          {singular[kind]?.toLowerCase()}.
        </div>
      ) : kind === "relationships" ? (
        <Graph list={list} />
      ) : (
        <div className={kind === "timeline" ? "timeline" : "librarygrid"}>
          {list.map((e, i) => {
            const img = getImage(e);
            return (
              <article
                className="record panel"
                key={e.id}
                draggable={kind === "timeline"}
                onDragStart={(ev) =>
                  ev.dataTransfer.setData("text/plain", e.id)
                }
                onDragOver={(ev) => ev.preventDefault()}
                onDrop={(ev) => {
                  if (kind !== "timeline") return;
                  const x = all.find(
                    (x) => x.id === ev.dataTransfer.getData("text/plain"),
                  );
                  if (x)
                    set((v) => ({
                      ...v,
                      entries: v.entries.map((y) =>
                        y.id === x.id
                          ? {
                              ...y,
                              meta: { ...y.meta, Sequence: e.meta.Sequence },
                            }
                          : y.id === e.id
                            ? {
                                ...y,
                                meta: { ...y.meta, Sequence: x.meta.Sequence },
                              }
                            : y,
                      ),
                    }));
                }}
              >
                {img ? (
                  <button
                    className="recordimg"
                    onClick={() => open(e)}
                    aria-label={"Open " + e.title}
                  >
                    <img src={img} alt="" />
                  </button>
                ) : null}
                <div className="recordbody">
                  <div className="between">
                    <small className="eyebrow gold">
                      {kind === "timeline"
                        ? `ERA ${e.meta.Sequence} / ${e.category}`
                        : e.category || singular[kind]}
                    </small>
                    <Icon k={kind} size={15} />
                  </div>
                  <button className="recordtitle" onClick={() => open(e)}>
                    {e.title}
                  </button>
                  <p>{e.summary}</p>
                  {kind === "timeline" &&
                    all.some(
                      (x) =>
                        x.id !== e.id &&
                        x.meta.Sequence === e.meta.Sequence &&
                        x.meta.Characters === e.meta.Characters &&
                        x.meta.Locations !== e.meta.Locations,
                    ) && (
                      <p className="gold">
                        Review: conflicting location in this sequence.
                      </p>
                    )}
                  {kind === "story-arcs" && (
                    <Meter
                      label="Development"
                      value={Number(e.meta.Completion) || 0}
                    />
                  )}
                  <div className="recordfoot">
                    <span className="badge status">
                      {kind === "continuity" ? e.meta.Severity + " · " : ""}
                      {e.status}
                    </span>
                    {kind === "notes" ? (
                      <button
                        onClick={() =>
                          save(
                            {
                              ...e,
                              meta: {
                                ...e.meta,
                                Pinned: e.meta.Pinned === "yes" ? "no" : "yes",
                              },
                            },
                            true,
                          )
                        }
                      >
                        <Pin size={13} />
                        {e.meta.Pinned === "yes" ? "Unpin" : "Pin"}
                      </button>
                    ) : kind === "continuity" ? (
                      <button
                        onClick={() =>
                          save({
                            ...e,
                            status: e.status === "Open" ? "Resolved" : "Open",
                          })
                        }
                      >
                        {e.status === "Open" ? "Resolve" : "Reopen"}
                      </button>
                    ) : (
                      <button onClick={() => open(e)}>
                        Details <ArrowUpRight size={13} />
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </>
  );
}
function Graph({ list }: { list: Entry[] }) {
  const { p, open } = useStudio();
  const names = [
    ...new Set(list.flatMap((e) => [e.meta.From, e.meta.To]).filter(Boolean)),
  ];
  const pos = (n: string) => {
    const i = names.indexOf(n);
    return i === 0
      ? { x: 350, y: 180 }
      : {
          x:
            350 +
            260 *
              Math.cos((2 * Math.PI * (i - 1)) / Math.max(1, names.length - 1)),
          y:
            180 +
            132 *
              Math.sin((2 * Math.PI * (i - 1)) / Math.max(1, names.length - 1)),
        };
  };
  return (
    <>
      <div className="panel graph">
        <svg
          viewBox="0 0 700 360"
          role="group"
          aria-label="Character relationship map"
        >
          {list.map((e) => {
            const a = pos(e.meta.From),
              b = pos(e.meta.To);
            return (
              <g key={e.id} onClick={() => open(e)}>
                <line
                  x1={a.x}
                  x2={b.x}
                  y1={a.y}
                  y2={b.y}
                  stroke={e.category === "Conflict" ? "#b77760" : "#829575"}
                  strokeWidth={2}
                  strokeDasharray={
                    e.category === "Conflict" ? "6 4" : undefined
                  }
                />
                <line
                  x1={a.x}
                  x2={b.x}
                  y1={a.y}
                  y2={b.y}
                  stroke="transparent"
                  strokeWidth="18"
                />
              </g>
            );
          })}
          {names.map((n) => {
            const a = pos(n),
              c = p.entries.find(
                (x) => x.kind === "characters" && x.title === n,
              );
            return (
              <g
                key={n}
                tabIndex={0}
                role="button"
                aria-label={"Open " + n}
                onKeyDown={(e) => {
                  if (c && (e.key === "Enter" || e.key === " ")) open(c);
                }}
                onClick={() => c && open(c)}
              >
                <rect
                  x={a.x - 44}
                  y={a.y - 17}
                  width="88"
                  height="34"
                  rx="16"
                  fill="#26372c"
                  stroke="#8a9a7b"
                />
                <text
                  x={a.x}
                  y={a.y + 5}
                  fill="#f3ecd9"
                  fontSize="14"
                  textAnchor="middle"
                >
                  {n}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
      {list.map((e) => (
        <button key={e.id} className="result" onClick={() => open(e)}>
          <GitBranch size={16} />
          <span>
            {e.meta.From} → {e.meta.To}
          </span>
          <small>{e.category}</small>
        </button>
      ))}
    </>
  );
}
