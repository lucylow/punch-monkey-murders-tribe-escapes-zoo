"use client";
import { useState, useRef } from "react";
import { useStudio, PageHead } from "./studio-ui";
import { statuses, words, download, Entry } from "@/lib/studio";
import {
  Plus,
  Search,
  BookOpen,
  Check,
  PenLine,
  Copy,
  Archive,
  Trash2,
  Bold,
  Italic,
  Underline,
  Heading2,
  Quote,
  List,
  ListOrdered,
  Undo2,
  Redo2,
} from "lucide-react";
export function Planner() {
  const { p, set, create, open, save, edit, notice } = useStudio(),
    [view, V] = useState("Table"),
    [q, Q] = useState(""),
    [status, S] = useState(""),
    [part, P] = useState(""),
    [who, W] = useState(""),
    [arc, A] = useState(""),
    [sort, T] = useState("Chapter"),
    [ids, select] = useState<string[]>([]);
  const chapters = p.entries.filter((e) => e.kind === "chapters"),
    rows = chapters
      .filter(
        (e) =>
          (!status ? e.status !== "Archived" : e.status === status) &&
          (!part || e.category === part) &&
          (!who || e.meta.Characters?.includes(who)) &&
          (!arc || e.meta["Story arc"] === arc) &&
          (e.title + " " + e.number).toLowerCase().includes(q.toLowerCase()),
      )
      .sort((a, b) =>
        sort === "Words"
          ? words(b.content) - words(a.content)
          : sort === "Last edited"
            ? b.updated.localeCompare(a.updated)
            : sort === "Status"
              ? a.status.localeCompare(b.status)
              : a.number - b.number,
      );
  function bulk(field: "status" | "category", val: string) {
    if (!val) return;
    set((v) => ({
      ...v,
      entries: v.entries.map((e) =>
        ids.includes(e.id) ? { ...e, [field]: val } : e,
      ),
    }));
    notice(`${ids.length} chapters updated`);
    select([]);
  }
  return (
    <>
      <PageHead
        eyebrow="WRITING WORKSPACE"
        title="Chapter planner"
        sub="Shape the manuscript, one chapter at a time."
      >
        <button className="goldbtn" onClick={() => create("chapters")}>
          <Plus />
          New chapter
        </button>
      </PageHead>
      <div className="tools">
        <input
          aria-label="Search chapters"
          placeholder="Search chapters…"
          value={q}
          onChange={(e) => Q(e.target.value)}
        />
        {[
          [status, S, "All statuses", statuses],
          [
            part,
            P,
            "All parts",
            Array.from(new Set(chapters.map((c) => c.category))),
          ],
          [
            who,
            W,
            "All characters",
            p.entries
              .filter((e) => e.kind === "characters")
              .map((e) => e.title),
          ],
          [
            arc,
            A,
            "All arcs",
            p.entries
              .filter((e) => e.kind === "story-arcs")
              .map((e) => e.title),
          ],
        ].map(([val, fn, label, options]) => (
          <select
            aria-label={String(label)}
            key={String(label)}
            value={String(val)}
            onChange={(e) => (fn as (s: string) => void)(e.target.value)}
          >
            <option value="">{String(label)}</option>
            {(options as string[]).map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        ))}
        <select
          aria-label="Sort chapters"
          value={sort}
          onChange={(e) => T(e.target.value)}
        >
          {["Chapter", "Words", "Last edited", "Status"].map((x) => (
            <option key={x}>{x}</option>
          ))}
        </select>
        <button onClick={() => V(view === "Table" ? "Board" : "Table")}>
          {view === "Table" ? "Board view" : "Table view"}
        </button>
      </div>
      <p className="listcount">
        {rows.length} CHAPTERS · {view.toUpperCase()} VIEW
      </p>
      {ids.length > 0 && (
        <div className="tools">
          <strong>{ids.length} selected</strong>
          <select
            aria-label="Bulk status"
            value=""
            onChange={(e) => bulk("status", e.target.value)}
          >
            <option value="">Change status…</option>
            {statuses.map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
          <select
            aria-label="Bulk part"
            value=""
            onChange={(e) => bulk("category", e.target.value)}
          >
            <option value="">Move to part…</option>
            {[...new Set(chapters.map((c) => c.category))].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
          <button
            onClick={() =>
              download(
                "selected-chapters.md",
                chapters
                  .filter((c) => ids.includes(c.id))
                  .map((c) => `# ${c.title}\n\n${c.content}`)
                  .join("\n\n"),
              )
            }
          >
            Export selected
          </button>
        </div>
      )}
      {!rows.length ? (
        <p className="empty">
          No chapters match your filters. Try another search or create a
          chapter.
        </p>
      ) : view === "Table" ? (
        <div className="tablewrap">
          <table>
            <thead>
              <tr>
                <th>
                  <input
                    aria-label="Select visible chapters"
                    type="checkbox"
                    checked={rows.every((c) => ids.includes(c.id))}
                    onChange={(e) =>
                      select(e.target.checked ? rows.map((c) => c.id) : [])
                    }
                  />
                </th>
                {[
                  "Chapter",
                  "Title",
                  "Part",
                  "Story arc",
                  "Status",
                  "Words",
                  "Characters",
                  "Edited",
                ].map((s) => (
                  <th key={s}>{s}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td>
                    <input
                      aria-label={"Select " + c.title}
                      type="checkbox"
                      checked={ids.includes(c.id)}
                      onChange={() =>
                        select(
                          ids.includes(c.id)
                            ? ids.filter((x) => x !== c.id)
                            : [...ids, c.id],
                        )
                      }
                    />
                  </td>
                  <td>{c.number}</td>
                  <td>
                    <button onClick={() => open(c)}>{c.title}</button>
                  </td>
                  <td>{c.category}</td>
                  <td>{c.meta["Story arc"]}</td>
                  <td>
                    <button className="badge status" onClick={() => edit(c)}>
                      {c.status}
                    </button>
                  </td>
                  <td>{words(c.content)}</td>
                  <td>{c.meta.Characters}</td>
                  <td>{c.updated.slice(0, 10)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="board">
          {statuses.slice(0, 6).map((s) => (
            <section
              className="panel"
              key={s}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                const c = chapters.find(
                  (x) => x.id === e.dataTransfer.getData("text/plain"),
                );
                if (c) save({ ...c, status: s });
              }}
            >
              <h3>{s}</h3>
              {rows
                .filter((c) => c.status === s)
                .map((c) => (
                  <button
                    draggable
                    onDragStart={(e) =>
                      e.dataTransfer.setData("text/plain", c.id)
                    }
                    className="boardcard"
                    key={c.id}
                    onClick={() => edit(c)}
                  >
                    <small>CHAPTER {c.number}</small>
                    {c.title}
                  </button>
                ))}
            </section>
          ))}
        </div>
      )}
    </>
  );
}
export function Manuscript() {
  const { p, set, create, edit, save, remove, notice } = useStudio();
  const cs = p.entries.filter(
      (x) => x.kind === "chapters" && x.status !== "Archived",
    ),
    c = cs.find((x) => x.id === p.current) || cs[0];
  const [q, Q] = useState(""),
    [part, P] = useState(c?.category || ""),
    ref = useRef<HTMLTextAreaElement>(null),
    history = useRef<{ a: string[]; b: string[] }>({ a: [], b: [] });
  function update(text: string) {
    if (!c) return;
    history.current.a.push(c.content);
    history.current.b = [];
    save({ ...c, content: text }, true);
  }
  function format(pre: string, post = "") {
    const t = ref.current;
    if (!t) return;
    const a = t.selectionStart,
      b = t.selectionEnd;
    update(
      c.content.slice(0, a) +
        pre +
        c.content.slice(a, b) +
        post +
        c.content.slice(b),
    );
    requestAnimationFrame(() => {
      t.focus();
      t.setSelectionRange(a + pre.length, b + pre.length);
    });
  }
  function reorder(src: string, dest: string) {
    set((v) => {
      const all = [...v.entries],
        i = all.findIndex((x) => x.id === src),
        j = all.findIndex((x) => x.id === dest);
      if (i < 0 || j < 0) return v;
      const [item] = all.splice(i, 1);
      all.splice(j, 0, item);
      return { ...v, entries: all };
    });
  }
  return (
    <>
      <PageHead
        eyebrow="WRITING WORKSPACE"
        title="Manuscript"
        sub="A quiet place to return to the page."
      >
        <button className="goldbtn" onClick={() => create("chapters")}>
          <Plus />
          New chapter
        </button>
      </PageHead>
      <div className="editorlayout">
        <aside className="panel indexlist">
          <h3>Chapter index</h3>
          <input
            aria-label="Find in manuscript"
            placeholder="Find in manuscript…"
            value={q}
            onChange={(e) => Q(e.target.value)}
          />
          <select
            aria-label="Manuscript part"
            value={part}
            onChange={(e) => P(e.target.value)}
          >
            <option value="">All parts</option>
            {[...new Set(cs.map((c) => c.category))].map((s) => (
              <option value={s} key={s}>
                Part {s}
              </option>
            ))}
          </select>
          {cs
            .filter(
              (x) =>
                (!part || part === x.category) &&
                (x.title + " " + x.content + " " + x.number)
                  .toLowerCase()
                  .includes(q.toLowerCase()),
            )
            .map((x) => (
              <button
                draggable
                onDragStart={(e) => e.dataTransfer.setData("text/plain", x.id)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) =>
                  reorder(e.dataTransfer.getData("text/plain"), x.id)
                }
                className={c?.id === x.id ? "chosen" : ""}
                onClick={() => {
                  set((v) => ({ ...v, current: x.id }));
                  history.current = { a: [], b: [] };
                }}
                key={x.id}
              >
                <small>
                  {x.number} · {x.status}
                </small>
                {x.title}
              </button>
            ))}
        </aside>
        {c && (
          <>
            <section className="panel writing">
              <div className="between">
                <small className="eyebrow gold">CHAPTER {c.number}</small>
                <small>
                  <Check size={12} /> Autosaved locally
                </small>
              </div>
              <input
                aria-label="Chapter title"
                className="titleinput"
                value={c.title}
                onChange={(e) => save({ ...c, title: e.target.value }, true)}
              />
              <div className="toolbar">
                {[
                  { i: Bold, n: "Bold", a: "**", b: "**" },
                  { i: Italic, n: "Italic", a: "*", b: "*" },
                  { i: Underline, n: "Underline", a: "<u>", b: "</u>" },
                  { i: Heading2, n: "Heading", a: "\n## " },
                  { i: Quote, n: "Quote", a: "\n> " },
                  { i: List, n: "Bulleted list", a: "\n- " },
                  { i: ListOrdered, n: "Numbered list", a: "\n1. " },
                ].map((f) => (
                  <button
                    key={f.n}
                    title={f.n}
                    aria-label={f.n}
                    onClick={() => format(f.a, f.b)}
                  >
                    <f.i size={15} />
                  </button>
                ))}
                {[false, true].map((redo) => (
                  <button
                    key={String(redo)}
                    aria-label={redo ? "Redo" : "Undo"}
                    onClick={() => {
                      const h = history.current;
                      const v = (redo ? h.b : h.a).pop();
                      if (v !== undefined) {
                        (redo ? h.a : h.b).push(c.content);
                        save({ ...c, content: v }, true);
                      }
                    }}
                  >
                    {redo ? <Redo2 size={15} /> : <Undo2 size={15} />}
                  </button>
                ))}
              </div>
              <textarea
                ref={ref}
                aria-label="Manuscript content"
                placeholder="Begin this chapter…"
                style={{ fontFamily: p.font, fontSize: p.fontSize }}
                value={c.content}
                onChange={(e) => update(e.target.value)}
              />
              <div className="editorfoot">
                {words(c.content)} words ·{" "}
                {Math.ceil(words(c.content) / p.pageSize)} pages{" "}
                <span>Markdown editor</span>
              </div>
            </section>
            <aside className="panel inspector">
              <h3>Chapter details</h3>
              <label>
                Status
                <select
                  value={c.status}
                  onChange={(e) => save({ ...c, status: e.target.value })}
                >
                  {statuses.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <small className="eyebrow">SUMMARY</small>
              <p>{c.summary}</p>
              {["Characters", "Locations", "STEM tags", "Goals"].map((k) => (
                <div key={k}>
                  <small className="eyebrow">{k}</small>
                  <p>{c.meta[k] || "Not assigned"}</p>
                </div>
              ))}
              <button onClick={() => edit(c)}>
                <PenLine size={14} /> Edit details
              </button>
              <button
                onClick={() =>
                  save({
                    ...c,
                    id: "",
                    number: Math.max(...cs.map((x) => x.number)) + 1,
                    title: c.title + " (copy)",
                  })
                }
              >
                <Copy size={14} /> Duplicate
              </button>
              <button onClick={() => save({ ...c, status: "Archived" })}>
                <Archive size={14} /> Archive
              </button>
              <button onClick={() => remove(c)}>
                <Trash2 size={14} /> Delete
              </button>
            </aside>
          </>
        )}
      </div>
    </>
  );
}
