"use client";
import { useState } from "react";
import { Entry, fields, getImage, singular } from "@/lib/studio";
import { Modal, useStudio } from "./studio-ui";
import { ArrowUpRight, PenLine } from "lucide-react";
export default function Dossier({ e, close }: { e: Entry; close: () => void }) {
  const { p, edit, open } = useStudio(),
    [tab, T] = useState("Overview");
  const char = e.kind === "characters",
    tabs = char
      ? [
          "Overview",
          "Personality",
          "Backstory",
          "Strengths & fears",
          "Relationships",
          "Appearances",
          "Writer’s notes",
        ]
      : ["Overview", "References", "Notes"];
  const links = p.entries.filter(
      (x) =>
        x.id !== e.id &&
        (x.meta.Characters || "")
          .split(",")
          .map((s) => s.trim())
          .includes(e.title),
    ),
    rels = p.entries.filter(
      (x) =>
        x.kind === "relationships" &&
        [x.meta.From, x.meta.To].includes(e.title),
    );
  const keys =
    tab === "Overview"
      ? char
        ? ["Species", "Physical description", "Character arc"]
        : fields[e.kind] || []
      : tab === "Personality"
        ? ["Personality", "Goals", "Motivations"]
        : tab === "Backstory"
          ? ["Backstory"]
          : tab === "Strengths & fears"
            ? ["Strengths", "Weaknesses", "Fears"]
            : tab === "Writer’s notes"
              ? ["Important scenes", "Dialogue notes", "Continuity notes"]
              : [];
  const refList =
    tab === "Relationships"
      ? rels
      : tab === "Appearances"
        ? links
        : p.entries.filter(
            (x) =>
              [
                e.meta.From,
                e.meta.To,
                ...(e.meta.Characters || "").split(",").map((s) => s.trim()),
                e.meta.Locations,
              ].includes(x.title) ||
              (x.kind === "chapters" && String(x.number) === e.meta.Chapters),
          );
  return (
    <Modal title={e.title} close={close}>
      {getImage(e) && (
        <div className="dossier-photo">
          <img src={getImage(e)} alt={e.title} />
        </div>
      )}
      <div className="between">
        <small className="eyebrow gold">
          {singular[e.kind]} · {e.category}
        </small>
        <span className="badge status">{e.status}</span>
      </div>
      <div className="dossiertabs">
        {tabs.map((t) => (
          <button key={t} aria-pressed={t === tab} onClick={() => T(t)}>
            {t}
          </button>
        ))}
      </div>
      {tab === "Overview" && <p>{e.summary}</p>}
      {keys
        .filter((k) => e.meta[k])
        .map((k) => (
          <section className="dossierfield" key={k}>
            <small className="eyebrow">{k}</small>
            <p>{e.meta[k]}</p>
          </section>
        ))}
      {["Relationships", "Appearances", "References"].includes(tab) ? (
        refList.length ? (
          refList.slice(0, 40).map((x) => (
            <button className="result" key={x.id} onClick={() => open(x)}>
              <span>{x.title}</span>
              <small>
                {singular[x.kind]} {x.number || ""}
              </small>
              <ArrowUpRight size={13} />
            </button>
          ))
        ) : (
          <p>No linked records yet.</p>
        )
      ) : tab === "Notes" ? (
        <p>{e.notes || "No notes added yet."}</p>
      ) : tab !== "Overview" && !keys.some((k) => e.meta[k]) ? (
        <p>No details recorded yet. Edit this profile to add them.</p>
      ) : null}
      <div className="dialogactions">
        <button onClick={close}>Close</button>
        <button className="goldbtn" onClick={() => edit(e)}>
          <PenLine size={14} />
          Edit {singular[e.kind].toLowerCase()}
        </button>
      </div>
    </Modal>
  );
}
