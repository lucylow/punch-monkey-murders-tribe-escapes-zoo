"use client";
import { useStudio, Meter } from "./studio-ui";
import { words, getImage } from "@/lib/studio";
import {
  BookOpen,
  Feather,
  ArrowRight,
  MapPin,
  UsersRound,
  PenLine,
  BookMarked,
  Activity,
  ChartNoAxesCombined,
  Clock3,
  Layers,
  Check,
  NotebookPen,
  Mountain,
  GitBranch,
  ShieldCheck,
} from "lucide-react";
export default function Dashboard() {
  const { p, nav, open, set, create } = useStudio();
  const all = (k: string) =>
    p.entries.filter((e) => e.kind === k && e.status !== "Archived");
  const ch = all("chapters"),
    cast = all("characters"),
    total = ch.reduce((s, c) => s + words(c.content), 0),
    complete = ch.filter((c) => c.status === "Complete").length,
    cur = ch.find((x) => x.id === p.current) || ch[0],
    arcs = all("story-arcs"),
    research = all("research"),
    issues = all("continuity");
  return (
    <>
      <section className="hero">
        <div className="hero-content">
          <div className="hero-top">
            <span className="eyebrow">
              <i /> PROJECT OVERVIEW
            </span>
            <span className="badge">
              <b />
              In development
            </span>
          </div>
          <h1>
            {p.title === "The Stuffed God of Monkey Mountain" ? (
              <>
                The Stuffed God of
                <br />
                Monkey Mountain
              </>
            ) : (
              p.title
            )}
          </h1>
          <p>{p.subtitle}</p>
          <button
            className="goldbtn"
            onClick={() => (cur ? open(cur) : create("chapters"))}
          >
            <Feather size={16} />
            Continue writing
            <ArrowRight size={15} />
          </button>
        </div>
        <span className="hero-index">FIELD NOTES &nbsp; / &nbsp; VOL. 01</span>
      </section>
      <div className="metricgrid">
        {[
          {
            icon: BookOpen,
            label: "Planned chapters",
            n: ch.length,
            foot: `${complete} completed`,
            route: "chapters",
            tone: "amber",
          },
          {
            icon: PenLine,
            label: "Manuscript words",
            n: total,
            foot: `of ${p.target.toLocaleString()} target`,
            route: "manuscript",
            tone: "sage",
          },
          {
            icon: UsersRound,
            label: "Characters",
            n: cast.length,
            foot: "In the story bible",
            route: "characters",
            tone: "rust",
          },
          {
            icon: MapPin,
            label: "Locations",
            n: all("locations").length,
            foot: "Across the story world",
            route: "locations",
            tone: "teal",
          },
        ].map((m) => (
          <button
            className={"metric " + m.tone}
            key={m.label}
            onClick={() => nav(m.route)}
          >
            <div>
              <span className="tile">
                <m.icon size={18} />
              </span>
              <span>{m.label}</span>
            </div>
            <strong>{m.n.toLocaleString()}</strong>
            <small>{m.foot}</small>
          </button>
        ))}
      </div>
      <div className="overview-cols">
        <section className="panel current">
          <div className="panelhead">
            <span>
              <BookMarked />
              Writing desk
            </span>
            <small className="eyebrow">CURRENT CHAPTER</small>
          </div>
          {cur && (
            <>
              <div className="chaptercover">
                <span className="phototag">
                  PART {cur.category} <i />{" "}
                  {cur.meta["Story arc"] || "MANUSCRIPT"}
                </span>
              </div>
              <div className="chapterbody">
                <div className="between">
                  <small className="eyebrow gold">CHAPTER {cur.number}</small>
                  <span className="badge status">
                    <b />
                    {cur.status}
                  </span>
                </div>
                <h2>{cur.title}</h2>
                <p>{cur.summary}</p>
                <button className="textlink" onClick={() => open(cur)}>
                  Open chapter <ArrowRight size={14} />
                </button>
              </div>
            </>
          )}
        </section>
        <section className="panel">
          <div className="panelhead">
            <span>
              <ChartNoAxesCombined />
              Project progress
            </span>
            <button
              className="iconbtn"
              aria-label="View analytics"
              onClick={() => nav("analytics")}
            >
              <ArrowRight size={16} />
            </button>
          </div>
          <div className="progressbody">
            <Meter
              label="Manuscript word goal"
              value={(total / p.target) * 100}
            />
            <Meter
              label="Chapter completion"
              value={(complete / ch.length) * 100}
              color="#d3ac68"
            />
            <Meter
              label="Story arc development"
              value={
                arcs.reduce((s, x) => s + Number(x.meta.Completion || 0), 0) /
                arcs.length
              }
              color="#90abad"
            />
            <Meter
              label="Research verified"
              value={
                (research.filter((x) => x.status === "Verified").length /
                  research.length) *
                100
              }
              color="#bb9273"
            />
            <Meter
              label="Continuity review"
              value={
                (issues.filter((x) => x.status === "Resolved").length /
                  issues.length) *
                100
              }
            />
            <div className="goalnote">
              <BookOpen size={15} />
              {p.pages} planned pages <i /> {arcs.length} story arcs
            </div>
          </div>
        </section>
      </div>
      <section className="castsection">
        <div className="sectionhead">
          <div>
            <small className="eyebrow">STORY BIBLE</small>
            <h2>Meet the cast</h2>
          </div>
          <button className="textlink" onClick={() => nav("characters")}>
            All characters <ArrowRight size={14} />
          </button>
        </div>
        <div className="castgrid">
          {cast.slice(0, 4).map((c) => (
            <button className="castcard" onClick={() => open(c)} key={c.id}>
              {getImage(c) && <img src={getImage(c)} alt="" />}
              <div>
                <small className="eyebrow">{c.category}</small>
                <h2>{c.title}</h2>
              </div>
            </button>
          ))}
        </div>
      </section>
      <div className="overview-cols">
        <section className="panel">
          <div className="panelhead">
            <span>
              <Activity />
              Studio activity
            </span>
          </div>
          {p.activity.slice(0, 5).map((a, i) => (
            <div className="lineitem" key={i}>
              <Clock3 size={15} />
              {a}
            </div>
          ))}
        </section>
        <section className="panel">
          <div className="panelhead">
            <span>
              <Mountain />
              Project milestones
            </span>
          </div>
          {[
            "Complete the escape sequence",
            "Finish the Tokyo survival arc",
            "Resolve the Sato confrontation",
            "Introduce the forest troop",
            "Complete Part Twenty-One",
            "Begin the next story arc",
          ].map((s, i) => (
            <label className="lineitem" key={s}>
              <input
                type="checkbox"
                checked={!!p.milestones[i]}
                onChange={() =>
                  set((v) => ({
                    ...v,
                    milestones: v.milestones.map((b, j) => (j === i ? !b : b)),
                  }))
                }
              />
              {s}
            </label>
          ))}
        </section>
      </div>
    </>
  );
}
