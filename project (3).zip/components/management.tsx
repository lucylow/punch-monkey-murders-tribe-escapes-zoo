"use client";
import { useRef, useState } from "react";
import { useStudio, PageHead } from "./studio-ui";
import { download, seed, valid, words, Entry, Project } from "@/lib/studio";
import { BarChart, Bar, XAxis, CartesianGrid, YAxis } from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Download, Upload, RotateCcw, ShieldCheck } from "lucide-react";
export function SettingsPage() {
  const { p, set, confirm, notice } = useStudio(),
    file = useRef<HTMLInputElement>(null);
  const change = (k: keyof Project, val: string | number | boolean) =>
    set((v) => ({ ...v, [k]: val }));
  return (
    <>
      <PageHead
        eyebrow="STUDIO PREFERENCES"
        title="Settings"
        sub="Make the writing space your own, and keep your project safe."
      />
      <div className="settingsgrid">
        <section className="panel setting">
          <h2>Project details</h2>
          <label>
            Novel title
            <input
              value={p.title}
              onChange={(e) => change("title", e.target.value)}
            />
          </label>
          <label>
            Project subtitle
            <textarea
              value={p.subtitle}
              onChange={(e) => change("subtitle", e.target.value)}
            />
          </label>
          <label>
            Project description
            <textarea
              value={p.description || ""}
              onChange={(e) => change("description", e.target.value)}
            />
          </label>
          <label>
            Default chapter status
            <select
              value={p.defaultStatus || "Idea"}
              onChange={(e) => change("defaultStatus", e.target.value)}
            >
              {[
                "Idea",
                "Outlined",
                "Drafting",
                "Revision",
                "Continuity Review",
                "Complete",
              ].map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label>
            Active timeline
            <select
              value={p.active}
              onChange={(e) => {
                const s = e.target.value;
                confirm(
                  "Switch the active timeline? Existing events will keep their chronology.",
                  () => change("active", s),
                );
              }}
            >
              {[
                "The Concrete Jungle — Post-Escape Timeline",
                "Beyond the City — Alternate Timeline",
              ].map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
        </section>
        <section className="panel setting">
          <h2>Appearance & editor</h2>
          {[
            ["Theme", "theme", p.theme, ["dark", "light"]],
            ["Accent", "accent", p.accent, ["Moss", "Amber", "Teal"]],
            ["Writing font", "font", p.font, ["Georgia", "Arial", "monospace"]],
          ].map(([label, k, val, opts]) => (
            <label key={String(k)}>
              {label}
              <select
                value={String(val)}
                onChange={(e) => change(k as keyof Project, e.target.value)}
              >
                {(opts as string[]).map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
            </label>
          ))}
          <label>
            Autosave timing
            <select
              value={p.autosaveDelay || 0}
              onChange={(e) => change("autosaveDelay", Number(e.target.value))}
            >
              <option value={0}>Immediately</option>
              <option value={500}>After a short pause</option>
              <option value={1500}>After 1.5 seconds</option>
            </select>
          </label>
          <label>
            Writing size · {p.fontSize}px
            <input
              type="range"
              min="14"
              max="26"
              value={p.fontSize}
              onChange={(e) => change("fontSize", +e.target.value)}
            />
          </label>
          <label className="checklabel">
            <input
              type="checkbox"
              checked={p.compact}
              onChange={(e) => change("compact", e.target.checked)}
            />
            Compact navigation
          </label>
        </section>
        <section className="panel setting">
          <h2>Manuscript targets</h2>
          {[
            ["Word count goal", "target"],
            ["Planned pages", "pages"],
            ["Words per page", "pageSize"],
          ].map(([s, k]) => (
            <label key={k}>
              {s}
              <input
                type="number"
                min="1"
                max="10000000"
                value={p[k as "target"]}
                onChange={(e) =>
                  change(
                    k as keyof Project,
                    Math.min(10000000, Math.max(1, +e.target.value)),
                  )
                }
              />
            </label>
          ))}
        </section>
        <section className="panel setting">
          <h2>Data management</h2>
          <p>
            Changes are stored in this browser. Export a copy before switching
            devices or clearing site data.
          </p>
          <div className="backupbuttons">
            <button
              onClick={() =>
                download("story-forge-project.json", JSON.stringify(p, null, 2))
              }
            >
              <Download />
              Export project JSON
            </button>
            <button onClick={() => file.current?.click()}>
              <Upload />
              Import project JSON
            </button>
            <input
              hidden
              ref={file}
              type="file"
              accept=".json,application/json"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (!f) return;
                try {
                  if (f.size > 4000000) throw Error();
                  const d = JSON.parse(await f.text());
                  if (!valid(d)) throw Error();
                  confirm(
                    `Replace the current workspace with “${d.title}”?`,
                    () => {
                      set(() => d);
                      notice("Project imported");
                    },
                  );
                } catch {
                  notice(
                    "Invalid project file. Import a Story Forge JSON backup under 4 MB.",
                  );
                }
              }}
            />
            {[true, false].map((full) => (
              <button
                key={String(full)}
                onClick={() =>
                  download(
                    full ? "manuscript.md" : "chapter-summaries.md",
                    p.entries
                      .filter(
                        (e) => e.kind === "chapters" && e.status !== "Archived",
                      )
                      .map(
                        (e) =>
                          `## Chapter ${e.number}: ${e.title}\n\n${full ? e.content : e.summary}`,
                      )
                      .join("\n\n"),
                  )
                }
              >
                <Download />
                {full
                  ? "Export manuscript Markdown"
                  : "Export chapter summaries"}
              </button>
            ))}
            <button
              className="delete"
              onClick={() =>
                confirm(
                  "Reset all local changes and restore the original demo? Export a backup first.",
                  () => {
                    set(() => seed());
                    notice("Demo restored");
                  },
                )
              }
            >
              <RotateCcw />
              Reset demo data
            </button>
          </div>
        </section>
      </div>
    </>
  );
}
export function AnalyticsPage() {
  const { p } = useStudio(),
    [since, S] = useState("");
  const entries = p.entries.filter(
      (e) => !since || e.updated.slice(0, 10) >= since,
    ),
    cs = entries.filter((e) => e.kind === "chapters");
  const group = (
    list: Entry[],
    f: (e: Entry) => string,
    score: (e: Entry) => number = () => 1,
  ) =>
    Object.entries(
      list.reduce(
        (v, e) => {
          const k = f(e) || "Unassigned";
          v[k] = (v[k] || 0) + score(e);
          return v;
        },
        {} as Record<string, number>,
      ),
    ).map(([name, value]) => ({ name, value }));
  const charts = [
    { title: "Chapters by status", data: group(cs, (e) => e.status) },
    {
      title: "Word count by part",
      data: group(
        cs,
        (e) => e.category,
        (e) => words(e.content),
      ),
    },
    {
      title: "Story arc completion (%)",
      data: group(
        entries.filter((e) => e.kind === "story-arcs"),
        (e) => e.title,
        (e) => Number(e.meta.Completion) || 0,
      ),
    },
    {
      title: "Character appearances",
      data: p.entries
        .filter((e) => e.kind === "characters")
        .map((e) => ({
          name: e.title,
          value: cs.filter((c) =>
            c.meta.Characters?.split(",")
              .map((n) => n.trim())
              .includes(e.title),
          ).length,
        }))
        .filter((d) => d.value),
    },
    {
      title: "STEM concept coverage",
      data: group(
        entries.filter((e) => e.kind === "stem"),
        (e) => e.category,
      ),
    },
    {
      title: "Continuity issues by severity",
      data: group(
        entries.filter((e) => e.kind === "continuity" && e.status === "Open"),
        (e) => e.meta.Severity,
      ),
    },
    {
      title: "Completed chapters by edit date",
      data: group(
        cs.filter((e) => e.status === "Complete"),
        (e) => e.updated.slice(0, 10),
      ),
    },
    {
      title: "Manuscript words by edit date",
      data: group(
        cs,
        (e) => e.updated.slice(0, 10),
        (e) => words(e.content),
      ),
    },
  ];
  return (
    <>
      <PageHead
        eyebrow="PROJECT INSIGHTS"
        title="Analytics"
        sub="A reading of your manuscript, drawn from the current workspace."
      />
      <div className="tools">
        <label>
          Edited since{" "}
          <input
            type="date"
            value={since}
            onChange={(e) => S(e.target.value)}
          />
        </label>
        <button onClick={() => S("")}>All dates</button>
      </div>
      <div className="settingsgrid">
        {charts.map((c) => (
          <section className="panel setting" key={c.title}>
            <h2>{c.title}</h2>
            {c.data.length ? (
              <ChartContainer
                className="h-48 w-full"
                config={{ value: { label: c.title, color: "var(--chart-1)" } }}
              >
                <BarChart data={c.data} accessibilityLayer>
                  <CartesianGrid vertical={false} strokeOpacity={0.12} />
                  <XAxis
                    dataKey="name"
                    tickFormatter={(x) => String(x).slice(0, 9)}
                    tickLine={false}
                    axisLine={false}
                    fontSize={10}
                  />
                  <YAxis
                    width={30}
                    tickLine={false}
                    axisLine={false}
                    fontSize={10}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="value" fill="var(--color-value)" radius={3} />
                </BarChart>
              </ChartContainer>
            ) : (
              <p>No activity for this date range.</p>
            )}
          </section>
        ))}
      </div>
    </>
  );
}
