"use client";
import { useEffect, useState } from "react";
import {
  Feather,
  PanelLeft,
  Search,
  Plus,
  Bell,
  ChevronRight,
  ChevronsUpDown,
  Check,
  Sun,
  Moon,
  Menu,
  X,
  BookOpen,
  ChevronDown,
  FolderOpen,
  Mountain,
  Command,
} from "lucide-react";
import {
  seed,
  labels,
  singular,
  Entry,
  Project,
  empty,
  key,
  valid,
  fields,
  statusList,
} from "@/lib/studio";
import { StudioContext, Modal, Icon } from "./studio-ui";
import Dashboard from "./dashboard";
import Dossier from "./dossier";
import { Planner, Manuscript } from "./writing";
import Library from "./library";
import { AnalyticsPage, SettingsPage } from "./management";
import { Button } from "@/components/ui/button";
const groups = [
  ["WORKSPACE", "overview", "manuscript", "chapters"],
  [
    "STORY BIBLE",
    "characters",
    "relationships",
    "locations",
    "worldbuilding",
    "timeline",
    "story-arcs",
  ],
  [
    "STUDIO TOOLS",
    "stem",
    "research",
    "continuity",
    "notes",
    "media",
    "analytics",
  ],
];
export default function Studio({ initial }: { initial: string }) {
  const [p, set] = useState(seed),
    [ready, loaded] = useState(false),
    [page, pageTo] = useState(initial),
    [mini, collapse] = useState(false),
    [drawer, showDrawer] = useState(false),
    [modal, show] = useState(""),
    [draft, editDraft] = useState<Entry | null>(null),
    [q, query] = useState(""),
    [msg, notice] = useState(""),
    [question, ask] = useState<{ s: string; fn: () => void } | null>(null),
    [storageError, se] = useState(false);
  useEffect(() => {
    try {
      const v = JSON.parse(localStorage.getItem(key) || "null");
      if (valid(v)) set(v);
    } catch {}
    loaded(true);
    const pop = () => {
      pageTo(location.pathname.slice(1) || "overview");
      show("");
      showDrawer(false);
    };
    window.addEventListener("popstate", pop);
    return () => window.removeEventListener("popstate", pop);
  }, []);
  useEffect(() => {
    if (ready) {
      const persist = () => {
        try {
          localStorage.setItem(key, JSON.stringify(p));
          se(false);
        } catch {
          se(true);
        }
      };
      if (!p.autosaveDelay) {
        persist();
        return;
      }
      const timer = setTimeout(persist, p.autosaveDelay);
      window.addEventListener("pagehide", persist);
      return () => {
        clearTimeout(timer);
        window.removeEventListener("pagehide", persist);
      };
    }
  }, [p, ready]);
  useEffect(() => {
    if (msg) {
      const t = setTimeout(() => notice(""), 3000);
      return () => clearTimeout(t);
    }
  }, [msg]);
  useEffect(() => {
    const keys = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        query("");
        show("search");
      }
      if (e.key === "Escape") showDrawer(false);
    };
    window.addEventListener("keydown", keys);
    return () => window.removeEventListener("keydown", keys);
  }, []);
  function nav(s: string) {
    history.pushState({}, "", s === "overview" ? "/" : "/" + s);
    pageTo(s);
    show("");
    showDrawer(false);
    window.scrollTo(0, 0);
  }
  function edit(e: Entry) {
    editDraft(structuredClone(e));
    show("edit");
  }
  function create(k: string) {
    edit({
      ...empty(k),
      status: k === "chapters" ? p.defaultStatus || "Idea" : statusList(k)[0],
      category: k === "chapters" ? "21" : "",
      number:
        k === "chapters"
          ? Math.max(
              0,
              ...p.entries.filter((x) => x.kind === k).map((x) => x.number),
            ) + 1
          : 0,
    });
  }
  function save(e: Entry, quiet = false) {
    const val = {
      ...e,
      id: e.id || crypto.randomUUID(),
      updated: new Date().toISOString(),
    };
    set((v) => ({
      ...v,
      entries: v.entries.some((x) => x.id === val.id)
        ? v.entries.map((x) => (x.id === val.id ? val : x))
        : [...v.entries, val],
      activity: quiet
        ? v.activity
        : [`${e.title} ${e.id ? "updated" : "created"}`, ...v.activity].slice(
            0,
            40,
          ),
    }));
    if (!quiet) {
      show("");
      notice(`${singular[e.kind]} saved`);
    }
  }
  function open(e: Entry) {
    if (e.kind === "chapters") {
      set((v) => ({ ...v, current: e.id }));
      nav("manuscript");
    } else {
      nav(e.kind);
      editDraft(e);
      show("detail");
    }
  }
  function confirm(s: string, fn: () => void) {
    ask({ s, fn });
  }
  function remove(e: Entry) {
    confirm(`Delete “${e.title}”? This cannot be undone.`, () => {
      set((v) => ({ ...v, entries: v.entries.filter((x) => x.id !== e.id) }));
      show("");
      notice("Record deleted");
    });
  }
  const search = p.entries
    .filter((e) =>
      !q
        ? ["Punch", "Ora", "The First Morning"].includes(e.title)
        : (e.title + " " + e.summary + " " + e.number)
            .toLowerCase()
            .includes(q.toLowerCase()),
    )
    .slice(0, 60);
  const theme = () =>
    set((v) => ({ ...v, theme: v.theme === "dark" ? "light" : "dark" }));
  const count = p.entries.filter(
    (x) => x.kind === "continuity" && x.status === "Open",
  ).length;
  return (
    <StudioContext.Provider
      value={{ p, set, nav, create, edit, open, save, remove, confirm, notice }}
    >
      <div
        className={
          "studio " +
          p.theme +
          (mini ? " mini" : "") +
          (drawer ? " drawer" : "") +
          (p.compact ? " compact" : "")
        }
        data-ready={ready}
        data-accent={p.accent}
      >
        {drawer && (
          <button
            className="scrim"
            aria-label="Close navigation"
            onClick={() => showDrawer(false)}
          />
        )}
        <aside className="sidebar">
          <div className="brand">
            <span className="brandmark">
              <Feather size={25} />
            </span>
            <div>
              <strong>The Story Forge</strong>
              <small>CREATIVE STUDIO</small>
            </div>
          </div>
          <button
            className="switcher"
            onClick={() => show("project")}
            title="Current project"
          >
            <span className="projectpic">
              <Mountain size={20} />
            </span>
            <span>
              <small>PROJECT WORKSPACE</small>Monkey Mountain
            </span>
            <ChevronsUpDown size={13} />
          </button>
          <nav>
            {groups.map(([name, ...ids]) => (
              <div className="navgroup" key={name}>
                <small className="eyebrow">{name}</small>
                {ids.map((s) => (
                  <a
                    key={s}
                    href={s === "overview" ? "/" : "/" + s}
                    onClick={(e) => {
                      if (e.ctrlKey || e.metaKey) return;
                      e.preventDefault();
                      nav(s);
                    }}
                    className={page === s ? "active" : ""}
                    aria-current={page === s ? "page" : undefined}
                    title={labels[s]}
                  >
                    <Icon k={s} />
                    <span>{labels[s]}</span>
                    {s === "continuity" && count > 0 && (
                      <b className="count">{count}</b>
                    )}
                  </a>
                ))}
              </div>
            ))}
          </nav>
          <div className="sidefoot">
            <button onClick={() => nav("settings")} title="Settings">
              <Icon k="settings" />
              <span>Settings</span>
            </button>
            <button
              className="iconbtn"
              aria-label="Collapse navigation"
              onClick={() => {
                collapse(!mini);
                showDrawer(false);
              }}
            >
              <PanelLeft size={15} />
            </button>
          </div>
        </aside>
        <div className="maincol">
          <header className="topbar">
            <div className="crumb">
              <button
                className="mobilemenu iconbtn"
                onClick={() => showDrawer(true)}
                aria-label="Open navigation"
              >
                <Menu size={20} />
              </button>
              <FolderOpen size={15} />
              <span>Workspace</span>
              <ChevronRight size={12} />
              <strong>
                {page === "overview" ? "Project overview" : labels[page]}
              </strong>
            </div>
            <div className="topactions">
              <button
                className="searchtrigger"
                onClick={() => {
                  query("");
                  show("search");
                }}
              >
                <Search size={15} />
                <span>Search studio...</span>
                <kbd>⌘ K</kbd>
              </button>
              <button className="createbtn" onClick={() => show("create")}>
                <Plus size={15} />
                <span>Create</span>
                <ChevronDown size={12} />
              </button>
              <button
                className="iconbtn themebtn"
                aria-label="Toggle theme"
                onClick={theme}
              >
                {p.theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
              </button>
              <button
                className="iconbtn bell"
                onClick={() => show("activity")}
                aria-label="Notifications"
              >
                <Bell size={17} />
                <b />
              </button>
              <button
                className="avatar"
                aria-label="Author settings"
                onClick={() => nav("settings")}
              >
                JD
              </button>
            </div>
          </header>
          <main key={page} className="workspace">
            {page === "overview" ? (
              <Dashboard />
            ) : page === "chapters" ? (
              <Planner />
            ) : page === "manuscript" ? (
              <Manuscript />
            ) : page === "analytics" ? (
              <AnalyticsPage />
            ) : page === "settings" ? (
              <SettingsPage />
            ) : (
              <Library kind={page} />
            )}
          </main>
          <footer className="studiofoot">
            <Feather size={13} /> Monkey Mountain Creative Studio{" "}
            <span>
              {storageError
                ? "Storage unavailable — export a backup"
                : "Saved on this device"}
            </span>
          </footer>
        </div>
        {modal === "search" && (
          <Modal title="Search the studio" close={() => show("")}>
            <input
              autoFocus
              className="full"
              aria-label="Search records"
              value={q}
              onChange={(e) => query(e.target.value)}
              placeholder="Search chapters, characters, notes…"
            />
            <small className="eyebrow blocklabel">
              {q ? "MATCHING RECORDS" : "SUGGESTED RECORDS"}
            </small>
            {search.map((e) => (
              <button className="result" key={e.id} onClick={() => open(e)}>
                <Icon k={e.kind} />
                <span>
                  {e.title}
                  <small>
                    {singular[e.kind]} {e.number || ""}
                  </small>
                </span>
                <ChevronRight size={14} />
              </button>
            ))}
            {!search.length && (
              <p>No matching records. Try a character name or chapter title.</p>
            )}
          </Modal>
        )}
        {modal === "create" && (
          <Modal title="Create in your studio" close={() => show("")}>
            <p>Choose what to add to your project.</p>
            <div className="creategrid">
              {Object.keys(singular).map((k) => (
                <button key={k} onClick={() => create(k)}>
                  <Icon k={k} />
                  {singular[k]}
                  <Plus size={13} />
                </button>
              ))}
            </div>
          </Modal>
        )}
        {modal === "project" && (
          <Modal title="Project workspace" close={() => show("")}>
            <div className="projectbanner" />
            <h3>{p.title}</h3>
            <p>{p.subtitle}</p>
            <div className="dialogactions">
              <button onClick={() => nav("overview")}>Open overview</button>
              <button onClick={() => nav("settings")}>Project settings</button>
            </div>
          </Modal>
        )}
        {modal === "activity" && (
          <Modal title="Studio notifications" close={() => show("")}>
            {p.activity.map((a, i) => (
              <div className="lineitem" key={i}>
                <Check size={14} />
                {a}
              </div>
            ))}
          </Modal>
        )}
        {modal === "detail" && draft && (
          <Dossier key={draft.id} e={draft} close={() => show("")} />
        )}
        {modal === "edit" && draft && (
          <Modal
            title={
              (draft.id ? "Edit " : "New ") + singular[draft.kind].toLowerCase()
            }
            close={() => show("")}
          >
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!draft.title.trim()) return;
                save({ ...draft, title: draft.title.trim() });
              }}
            >
              <label>
                Title
                <input
                  autoFocus
                  required
                  maxLength={180}
                  value={draft.title}
                  onChange={(e) =>
                    editDraft({ ...draft, title: e.target.value })
                  }
                />
              </label>
              <label>
                {draft.kind === "notes" ? "Note content" : "Summary"}
                <textarea
                  rows={3}
                  value={draft.summary}
                  onChange={(e) =>
                    editDraft({ ...draft, summary: e.target.value })
                  }
                />
              </label>
              <div className="fieldgrid">
                <label>
                  {draft.kind === "chapters"
                    ? "Part"
                    : draft.kind === "characters"
                      ? "Narrative role"
                      : "Category"}
                  <input
                    value={draft.category}
                    onChange={(e) =>
                      editDraft({ ...draft, category: e.target.value })
                    }
                  />
                </label>
                <label>
                  Status
                  <select
                    value={draft.status}
                    onChange={(e) =>
                      editDraft({ ...draft, status: e.target.value })
                    }
                  >
                    {statusList(draft.kind).map((v) => (
                      <option key={v}>{v}</option>
                    ))}
                  </select>
                </label>
              </div>
              <details
                open={["relationships", "continuity", "timeline"].includes(
                  draft.kind,
                )}
              >
                <summary>Details & references</summary>
                {(fields[draft.kind] || []).map((f) => (
                  <label key={f}>
                    {f}
                    {["From", "To", "Severity"].includes(f) ? (
                      <select
                        required
                        value={draft.meta[f] || ""}
                        onChange={(e) =>
                          editDraft({
                            ...draft,
                            meta: { ...draft.meta, [f]: e.target.value },
                          })
                        }
                      >
                        <option value="">Select {f.toLowerCase()}</option>
                        {(f === "Severity"
                          ? ["Low", "Medium", "High"]
                          : p.entries
                              .filter((c) => c.kind === "characters")
                              .map((c) => c.title)
                        ).map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        value={draft.meta[f] || ""}
                        onChange={(e) =>
                          editDraft({
                            ...draft,
                            meta: { ...draft.meta, [f]: e.target.value },
                          })
                        }
                      />
                    )}
                  </label>
                ))}
                <label>
                  Notes
                  <textarea
                    value={draft.notes}
                    onChange={(e) =>
                      editDraft({ ...draft, notes: e.target.value })
                    }
                  />
                </label>
              </details>
              <div className="dialogactions">
                {draft.id && (
                  <button
                    className="delete"
                    type="button"
                    onClick={() => remove(draft)}
                  >
                    Delete
                  </button>
                )}
                <button type="button" onClick={() => show("")}>
                  Cancel
                </button>
                <Button type="submit">
                  {draft.id
                    ? "Save changes"
                    : "Create " + singular[draft.kind].toLowerCase()}
                </Button>
              </div>
            </form>
          </Modal>
        )}
        {question && (
          <Modal title="Confirm change" close={() => ask(null)}>
            <p>{question.s}</p>
            <div className="dialogactions">
              <button onClick={() => ask(null)}>Cancel</button>
              <button
                className="goldbtn"
                onClick={() => {
                  question.fn();
                  ask(null);
                }}
              >
                Confirm
              </button>
            </div>
          </Modal>
        )}
        {(msg || storageError) && (
          <div className="toast" role="status">
            {storageError
              ? "Local storage is full or unavailable. Export a backup in Settings."
              : msg}
          </div>
        )}
      </div>
    </StudioContext.Provider>
  );
}
