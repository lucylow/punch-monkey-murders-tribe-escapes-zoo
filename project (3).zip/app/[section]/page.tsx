import Studio from "@/components/studio";
import { labels } from "@/lib/studio";
import { notFound } from "next/navigation";
export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  if (!Object.hasOwn(labels, section)) notFound();
  return <Studio initial={section} />;
}
