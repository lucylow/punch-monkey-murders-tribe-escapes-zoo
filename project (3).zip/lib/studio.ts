import { nextSummaries, profiles } from "./story-detail";
export const labels: Record<string, string> = {
  overview: "Overview",
  manuscript: "Manuscript",
  chapters: "Chapter Planner",
  characters: "Characters",
  relationships: "Relationships",
  locations: "Locations",
  worldbuilding: "World Building",
  timeline: "Timeline",
  stem: "STEM Laboratory",
  "story-arcs": "Story Arcs",
  research: "Research Library",
  continuity: "Continuity Checker",
  notes: "Notes",
  media: "Media Library",
  analytics: "Analytics",
  settings: "Settings",
};
export const singular: Record<string, string> = {
  chapters: "Chapter",
  characters: "Character",
  locations: "Location",
  notes: "Note",
  "story-arcs": "Story Arc",
  stem: "STEM Concept",
  research: "Research Entry",
  continuity: "Continuity Issue",
  timeline: "Timeline Event",
  relationships: "Relationship",
  media: "Media Reference",
  worldbuilding: "World Entry",
};
export interface Entry {
  id: string;
  kind: string;
  title: string;
  summary: string;
  category: string;
  status: string;
  content: string;
  notes: string;
  meta: Record<string, string>;
  updated: string;
  number: number;
}
export interface Project {
  description?: string;
  defaultStatus?: string;
  autosaveDelay?: number;
  rules?: string[];
  version: 1;
  title: string;
  subtitle: string;
  theme: string;
  target: number;
  pages: number;
  pageSize: number;
  font: string;
  fontSize: number;
  compact: boolean;
  accent: string;
  active: string;
  current: string;
  entries: Entry[];
  activity: string[];
  milestones: boolean[];
}
export const statuses = [
  "Idea",
  "Outlined",
  "Drafting",
  "Revision",
  "Continuity Review",
  "Complete",
  "Archived",
];
export const fields: Record<string, string[]> = {
  chapters: [
    "Characters",
    "Locations",
    "Story arc",
    "STEM tags",
    "Themes",
    "Goals",
  ],
  characters: [
    "Species",
    "Personality",
    "Backstory",
    "Physical description",
    "Goals",
    "Motivations",
    "Fears",
    "Strengths",
    "Weaknesses",
    "Character arc",
    "Important scenes",
    "Dialogue notes",
    "Continuity notes",
  ],
  relationships: ["From", "To"],
  locations: [
    "Atmosphere",
    "Narrative purpose",
    "Objects",
    "Characters",
    "Chapters",
  ],
  worldbuilding: ["Characters", "Chapters", "Locations"],
  timeline: ["Era", "Sequence", "Characters", "Locations", "Chapters"],
  stem: [
    "Principle",
    "Encounter",
    "Observation",
    "Learning",
    "Chapters",
    "Locations",
    "Plausibility",
  ],
  research: ["Source name", "Example URL", "Confidence", "Chapters"],
  continuity: ["Severity", "Chapters", "Recommendation"],
  "story-arcs": [
    "Conflict",
    "Beginning",
    "Middle",
    "Ending",
    "Characters",
    "Chapters",
    "Themes",
    "Completion",
  ],
  notes: ["Tags", "Characters", "Chapters"],
  media: ["Tags", "Characters", "Chapters"],
};
export const statusList = (k: string) =>
  k === "chapters"
    ? statuses
    : k === "research" || k === "stem"
      ? ["Needs verification", "Researching", "Verified", "Archived"]
      : k === "continuity"
        ? ["Open", "Resolved"]
        : ["Active", "Planned", "Complete", "Archived"];
export const empty = (kind: string): Entry => ({
  kind,
  id: "",
  title: "",
  summary: "",
  category: kind === "chapters" ? "21" : "",
  status: statusList(kind)[0],
  content: "",
  notes: "",
  meta: {},
  updated: "2026-11-20",
  number: 0,
});
export const words = (t: string) =>
  t.trim() ? t.trim().split(/\s+/).length : 0;
const cast =
  "Punch|Ora|Kuro|Sato|Haruto|Dr. Arai|Dr. Mori|Nakamura|Toma|Hana|Nami|Saki|Yuki|Mio|Kenji|Aki|Ren|Fumi|Riku|Emi|Hiro|Aya|Mei|Jun|Nao|Yui|Sora|Kaede|Haru|Rin|Asa|Iori|Shin|Akira".split(
    "|",
  );
const places =
  "Monkey Mountain|The Nursery|The Original Hollow|Artificial Climbing Structure|Zoo Maintenance Corridor|Temporary Habitat|Drainage Channel|Tokyo Overpass|Tokyo Market District|Underground Railway Area|Abandoned Maintenance Building|Industrial Factory|Urban Green Space|Forest Edge|Mountain Stream|Natural Macaque Habitat|Sato’s Office|Riverside Path".split(
    "|",
  );
const arcs =
  "The Abandoned Infant|The Gift of Ora|The Curious Young Monkey|The Return to Monkey Mountain|The Rise of Kuro|The Rejected Outsider|The Broken Kingdom|The Great Escape|The Concrete Jungle|The Ghost Hunt|The Sato Confrontation|Beyond the Concrete|The New Troop|The Legacy of Punch".split(
    "|",
  );
const names =
  "The Familiar Hollow|The Transfer|The Return of the Alpha|The Hollow Remembers|The Storm Begins|The Structure Groans|The Broken Kingdom|Through the Drainage Channel|The Empty Hollow|The City Waiting|The First Morning|A Thousand Moving Parts|The First Meal|Ora’s Backpack|The Language of Traffic|The Underground River|The Dog|The Invisible Map|Sato’s Search|The First Safe Place|The Rattle of Shutters|A Pocket of Green|The Market Cat|The Second Rain|A Thread of Orange|The Shadow Shelter|Under the Tracks|A Familiar Scent|The Wrong Turn|A Quiet Hand|The Day Shift|The Listening Wall|The Fruit Seller|No Footprints|The Green Corridor|Another Crossing|The Empty Crate|Sato’s Notebook|The Long Watch|A Choice of Roads|The River Beyond|The Last Bridge|A Line of Trees|The Forest Edge|Water over Stones|The Watcher|A Distant Troop|The First Call|Room on the Branch|The Borrowed Nest|The Cold Morning|Grooming Distance|The Lost Button|A Place Beside Toma|Beneath the Cedars|The Open Hand|The Way Back|A Different Hollow|What Ora Keeps|The Mountain Remembers".split(
    "|",
  );
const summaries = [
  "Punch searches for the hollow whose shape he remembers.",
  "A familiar keeper arrives to move Punch to his former enclosure.",
  "Kuro claims the high platform, changing the rhythm of the troop.",
  "Punch finds the nesting place he once shared with Ora.",
  "Rain scatters the troop and masks its warning calls.",
  "The climbing structure shifts beneath the weight of the storm.",
  "The old structure collapses; Kuro’s fate remains uncertain.",
  "Punch carries Ora through the drainage channel before dawn.",
  "Sato finds the hollow empty and begins to search.",
  "Beyond the zoo, the city stretches ahead of Punch.",
  "Beneath a Tokyo overpass, Punch wakes to a city without the familiar rules of the zoo.",
  "Punch follows the repeated sounds of trains, traffic and footsteps.",
  "A bruised pear at the market offers a first meal.",
  "Punch holds Ora close as her worn seam begins to loosen.",
  "Familiar pauses in the traffic help Punch decide when to move.",
];
export function seed(): Project {
  const entries: Entry[] = [];
  function add(
    k: string,
    title: string,
    summary: string,
    category: string,
    meta: Record<string, string> = {},
  ) {
    const e = {
      ...empty(k),
      id: k + "-" + (entries.filter((x) => x.kind === k).length + 1),
      title,
      summary,
      category,
      meta,
    };
    entries.push(e);
    return e;
  }
  const periods = [
    "Nursery",
    "Keeper",
    "Old Hollow",
    "Rain",
    "Orange Thread",
    "High Branch",
    "New Troop",
    "Quiet Gate",
    "Night Shift",
    "Shelter",
    "Glass",
    "Stone",
    "Water",
    "Footsteps",
    "Cedar",
    "Mirror",
    "Fence",
    "Nest",
    "Shadow",
    "Wind",
    "Threshold",
  ];
  const motifs = [
    "First Light",
    "The Waiting Hour",
    "A Small Change",
    "What Remains",
    "A Familiar Sound",
    "The Other Side",
    "The Long Afternoon",
    "A New Distance",
    "A Place to Rest",
    "Nightfall",
  ];
  const prose =
    "The sound came before the light. Punch opened one eye and waited for the rhythm he knew: a pair of boots, the metal bowl, the little pause before a hand appeared. Nothing came. Beside him the orange cloth was cool against his wrist. He gathered it closer. Somewhere beyond the concrete a bird called twice, and a second bird answered. He stayed still until he could tell the two sounds apart.";
  for (let n = 1; n <= 270; n++) {
    const part = n >= 221 ? 21 : n >= 211 ? 20 : Math.ceil(n / 11);
    const title =
      names[n - 211] ||
      periods[Math.floor((n - 1) / 10)] + ": " + motifs[(n - 1) % 10];
    const loc = places[n > 250 ? 13 + (n % 3) : n > 220 ? 7 + (n % 5) : n % 7];
    const summary =
      summaries[n - 211] ||
      nextSummaries[n - 226] ||
      `${n % 6 === 0 ? "Sato" : "Punch"} ${["returns to", "waits beside", "listens near", "revisits", "finds shelter at"][n % 5]} ${loc}. ${["A familiar scent carries a memory of the nursery.", "The change in the morning routine draws attention to a missing companion.", "A sudden noise breaks the fragile calm.", "An unexpected meeting changes the distance between fear and trust.", "A small discovery marks the next step toward belonging."][Math.floor(n / 5) % 5]}`;
    const e = add("chapters", title, summary, String(part), {
      Characters: n % 4 ? "Punch, Ora" : "Sato",
      Locations: n === 221 ? "Tokyo Overpass" : loc,
      "Story arc": arcs[n >= 221 ? 8 : Math.min(7, Math.floor(n / 27))],
      "STEM tags": "Spatial memory",
    });
    e.number = n;
    e.status =
      n >= 199 && n <= 220
        ? "Complete"
        : n === 221
          ? "Drafting"
          : n > 221
            ? "Outlined"
            : n % 3
              ? "Revision"
              : "Drafting";
    e.content =
      n <= 221
        ? `${n === 221 ? prose : summary + "\n\n" + prose}\n\n${n === 221 ? "The first train moved over him like a storm that knew where it was going. Punch pressed his palm to the ground. When the trembling stopped, he lifted his head." : `At ${loc}, even the smallest movement had a sound. Punch turned toward it, then back toward the hollow where he had left Ora.`}`
        : "";
  }
  const roles = [
    "Protagonist",
    "Emotional anchor",
    "Antagonist",
    "Caretaker",
    "Conservation advocate",
    "Behaviour specialist",
    "Researcher",
    "Keeper",
    "Troop leader",
  ];
  const desc = [
    "A young Japanese macaque learns to find belonging through patience, observation, and memory.",
    "A worn stuffed orangutan with mismatched button eyes. Sato’s gift is Punch’s oldest source of comfort.",
    "A dominant macaque whose place in the troop depends on the distance others keep.",
    "The night keeper who raised Punch now searches for him beyond Monkey Mountain.",
  ];
  cast.forEach((n, i) =>
    add(
      "characters",
      n,
      desc[i] ||
        `${n} brings another perspective to ${i < 9 ? "the changing zoo" : "the community at the forest edge"}.`,
      roles[i] || "Supporting cast",
      {
        ...profiles[n],
        Species:
          i === 1
            ? "Stuffed orangutan"
            : i >= 3 && i <= 7
              ? "Human"
              : "Japanese macaque",
        Strengths:
          i === 0 ? "Spatial memory, agility, pattern recognition" : "",
        "Story arc": arcs[i % 14],
      },
    ),
  );
  places.forEach((n, i) =>
    add(
      "locations",
      n,
      `${n} anchors the ${i < 7 ? "Monkey Mountain" : i < 13 ? "Tokyo survival" : "forest"} sequence.`,
      i < 7 ? "Zoo habitat" : i < 13 ? "City" : "Woodland",
    ),
  );
  arcs.forEach((n, i) => {
    add(
      "story-arcs",
      n,
      `Track the turning points of ${n.toLowerCase()} and its impact on Punch.`,
      i < 8 ? "Monkey Mountain" : i < 11 ? "Tokyo" : "Forest",
      {
        Completion: i < 8 ? "100" : i === 8 ? "38" : "0",
        Characters: "Punch, Ora",
      },
    );
  });
  [
    "Attachment",
    "Caretaking",
    "Conflict",
    "Mentorship",
    "Trust",
    "Friendship",
    "Collaboration",
    "Inspiration",
  ].forEach((n, i) => {
    const a = [0, 0, 0, 0, 0, 0, 3, 4][i],
      b = [1, 3, 2, 8, 9, 10, 5, 0][i];
    add(
      "relationships",
      `${cast[a]} & ${cast[b]}`,
      `${n} connects ${cast[a]} and ${cast[b]}.`,
      n,
      { From: cast[a], To: cast[b] },
    );
  });
  [
    "Infancy",
    "Early Development",
    "Monkey Mountain",
    "Habitat Changes",
    "Storm and Escape",
    "The Concrete Jungle",
    "Beyond the City",
  ].forEach((n, i) =>
    add(
      "timeline",
      [
        "Sato brings Ora to the nursery",
        "Punch remembers the keeper’s rhythm",
        "Kuro claims the high platform",
        "The troop is transferred",
        "Punch leaves the hollow",
        "First light beneath the overpass",
        "A troop beyond the trees",
      ][i],
      `Story period ${i + 1}: ${n}.`,
      i === 6 ? "Future" : i < 2 ? "Flashback" : "Active",
      {
        Era: n,
        Sequence: String(i + 1),
        Characters: "Punch",
        Locations: places[[1, 1, 0, 5, 6, 7, 13][i]],
        Chapters: String([1, 25, 80, 160, 218, 221, 255][i]),
      },
    ),
  );
  [
    "Gravity",
    "Friction",
    "Mechanical Advantage",
    "Spatial Memory",
    "Fluid Dynamics",
    "Optics",
    "Materials Science",
    "Animal Behaviour",
  ].forEach((n, i) => {
    const e = add(
      "stem",
      n,
      [
        "An unsupported fruit always drops toward the ground.",
        "Wet concrete offers less grip than dry bark.",
        "Punch notices that equipment changes how a load moves.",
        "Repeated landmarks help Punch retrace a familiar route.",
        "Rainwater gathers and changes speed as the path narrows.",
        "An image in a window seems to move with Punch.",
        "Ora’s loose seams feel different from her intact fabric.",
        "Distance and grooming signal acceptance within a troop.",
      ][i],
      [
        "Physics",
        "Physics",
        "Engineering",
        "Cognitive Science",
        "Physics",
        "Physics",
        "Engineering",
        "Biology",
      ][i],
      { Plausibility: "4 / 5", Chapters: String(221 + i) },
    );
    e.status = i % 3 ? "Verified" : "Needs verification";
  });
  [
    "Nursery routines",
    "Macaque grooming",
    "Forest food cycles",
    "The elevated railway",
    "Market mornings",
    "Patterns of belonging",
  ].forEach((n, i) => {
    add(
      "worldbuilding",
      n,
      `A reference for how ${n.toLowerCase()} shape Punch’s daily experience.`,
      [
        "Zoo operations",
        "Animal behaviour",
        "Forest ecology",
        "Tokyo infrastructure",
        "Cultural context",
        "Social hierarchy",
      ][i],
    );
    let e = add(
      "research",
      n,
      `Mock research note: compare the manuscript’s portrayal of ${n.toLowerCase()} with a verified reference before publication.`,
      i % 2 ? "Environment" : "Animal cognition",
      { "Source name": "Demo field notebook", Confidence: "Provisional" },
    );
    e.status = i < 4 ? "Verified" : "Researching";
  });
  [
    "Kuro’s uncertain fate",
    "Punch’s post-escape location",
    "Ora’s changing seams",
    "Forest troop roles",
    "Timing of the transfer",
    "Forest chronology",
    "Overpass crossing",
  ].forEach((n, i) =>
    add(
      "continuity",
      n,
      [
        "Confirm Kuro’s condition before a later scene assumes his fate.",
        "Keep the first morning beneath the Tokyo overpass.",
        "Record which arm has the repaired stitching.",
        "Check Hana, Nami and Saki against earlier outlines.",
        "Confirm when Punch returns to Monkey Mountain.",
        "Future forest events must not precede the city arc.",
        "Check the location against the preceding scene.",
      ][i],
      i % 2 ? "Chronology" : "Story facts",
      { Severity: i % 2 ? "Medium" : "High", Chapters: String(217 + i) },
    ),
  );
  [
    "The weight of Ora",
    "Sounds before sunrise",
    "The keeper’s hesitation",
  ].forEach((n, i) =>
    add(
      "notes",
      n,
      [
        "Let the worn cloth carry the memory, without explaining the symbol.",
        "Before Punch sees the city, let him hear it.",
        "Sato pauses outside the empty hollow; give the silence space.",
      ][i],
      ["Character note", "Chapter note", "Plot idea"][i],
    ),
  );
  [
    "The cedar ridge",
    "Morning under the overpass",
    "Punch at first light",
  ].forEach((n, i) =>
    add(
      "media",
      n,
      "Visual reference for the atmosphere of the manuscript.",
      "Mood board",
      { Image: ["/forest.webp", "/overpass.webp", "/portrait-0.webp"][i] },
    ),
  );
  return {
    version: 1,
    description:
      "A psychological survival thriller about rejection, survival, science, and belonging.",
    defaultStatus: "Idea",
    autosaveDelay: 0,
    rules: [
      "Kuro died",
      "Kuro is dead",
      "Punch solved an equation",
      "Punch calculated the velocity",
    ],
    title: "The Stuffed God of Monkey Mountain",
    subtitle:
      "A story of abandonment, invention, survival, and the search for belonging.",
    theme: "dark",
    target: 80000,
    pages: 320,
    pageSize: 250,
    font: "Georgia",
    fontSize: 18,
    compact: false,
    accent: "Moss",
    active: "The Concrete Jungle — Post-Escape Timeline",
    current: "chapters-221",
    entries,
    activity: [
      "Chapter 220 completed",
      "Part Twenty-One outline created",
      "Ora’s character profile updated",
      "Kuro timeline conflict flagged",
      "Spatial memory research added",
    ],
    milestones: [true, false, false, false, false, false],
  };
}
export const key = "story-forge-studio-v1";
export function valid(p: unknown): p is Project {
  if (!p || typeof p !== "object") return false;
  const v = p as Project;
  return (
    v.version === 1 &&
    (!v.rules ||
      (Array.isArray(v.rules) &&
        v.rules.every((s) => typeof s === "string"))) &&
    (!v.autosaveDelay || [500, 1500].includes(v.autosaveDelay)) &&
    (!v.defaultStatus || statuses.includes(v.defaultStatus)) &&
    (!v.description || typeof v.description === "string") &&
    ["title", "subtitle", "theme", "current", "active", "font", "accent"].every(
      (k) => typeof (v as unknown as Record<string, unknown>)[k] === "string",
    ) &&
    [v.target, v.pages, v.pageSize, v.fontSize].every(
      (n) => Number.isFinite(n) && n > 0,
    ) &&
    Array.isArray(v.activity) &&
    v.activity.every((x) => typeof x === "string") &&
    Array.isArray(v.milestones) &&
    v.milestones.every((x) => typeof x === "boolean") &&
    Array.isArray(v.entries) &&
    v.entries.every(
      (e) =>
        e &&
        Object.hasOwn(singular, e.kind) &&
        [
          "id",
          "title",
          "summary",
          "content",
          "status",
          "notes",
          "category",
          "updated",
        ].every(
          (k) =>
            typeof (e as unknown as Record<string, unknown>)[k] === "string",
        ) &&
        Number.isFinite(e.number) &&
        e.meta &&
        typeof e.meta === "object" &&
        Object.values(e.meta).every((x) => typeof x === "string"),
    ) &&
    new Set(v.entries.map((e) => e.id)).size === v.entries.length
  );
}
export function download(name: string, data: string) {
  const url = URL.createObjectURL(
    new Blob([data], {
      type: name.endsWith(".json")
        ? "application/json"
        : "text/plain;charset=utf-8",
    }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function getImage(e: Entry) {
  const i = ["Punch", "Ora", "Kuro", "Sato"].indexOf(e.title);
  return e.kind === "characters" && i !== -1
    ? `/portrait-${i}.webp`
    : e.kind === "media" &&
        /^\/(forest|overpass|portrait-[0-3])\.webp$/.test(e.meta.Image)
      ? e.meta.Image
      : e.kind === "locations"
        ? e.category === "City"
          ? "/overpass.webp"
          : "/forest.webp"
        : "";
}
