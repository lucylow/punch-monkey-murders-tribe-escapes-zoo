export const nextSummaries = [
  "Beneath the street, the sound of running water recalls the hollow. Punch stops when its current grows louder.",
  "A loose dog changes Punch’s route to the market. He waits above its reach until the footsteps move on.",
  "Three familiar landmarks let Punch find his way back to shelter without following the same street.",
  "Sato listens to conflicting sightings and marks the last confirmed place Punch was seen.",
  "A ledge beneath the overpass offers a dry place to sleep with Ora pressed to his chest.",
  "The morning shutters rise in sequence. Punch begins to associate their clatter with discarded fruit.",
  "A strip of trees between buildings gives Punch a brief respite from the street.",
  "A market cat shares the edge of a stall; neither animal gives up its distance.",
  "The rain changes the smell of every familiar corner, and Punch loses the path home.",
  "A thread on Ora’s arm catches against a branch. Punch returns for the toy rather than the pear.",
  "Awnings cast a continuous ribbon of shade through the busiest part of the market.",
  "The rumble overhead becomes a cue to wait before crossing the open ground beneath the tracks.",
  "Sato’s coat carries the smell of the nursery, but the crowd is too close for Punch to approach.",
  "A shuttered lane makes a familiar route unrecognizable. Punch circles back to the last known corner.",
  "A shopkeeper sets down fruit and withdraws; distance makes the gesture easier to trust.",
  "The incoming zoo shift asks Sato for a timeline rather than another guess.",
  "Pressed against concrete, Punch senses a train before its sound reaches the street.",
  "The fruit seller notices the same small visitor returning at closing time.",
  "Overnight rain erases the tracks that had given Sato confidence in his map.",
  "Connected pockets of cover lead Punch away from the densest streets.",
  "A rushing bicycle interrupts a crossing, forcing Punch to wait for another quiet interval.",
  "An abandoned crate looks familiar but smells wrong. Punch chooses the branch above it.",
  "Sato replaces a guessed route in his notebook with the fruit seller’s account.",
  "From a distant bench Sato watches the tree line without calling or moving closer.",
  "At a fork in the green strip, Punch follows the sound of running water.",
  "The riverbank offers new food and unfamiliar birds; Punch keeps the overpass within sight.",
  "A bridge marks the final break between the built-up streets and the wooded slope.",
  "An uninterrupted line of trees gives Punch a route without crossing open pavement.",
  "At the woodland boundary, Punch pauses long enough for the traffic noise to fade.",
  "Wet stones shift under Punch’s feet. He tests a different crossing with a shallow step.",
  "Another macaque watches from a high fork but does not come down.",
  "The movement of a distant troop echoes patterns Punch remembers from Monkey Mountain.",
  "A contact call crosses the stream. Punch freezes, then follows at a distance.",
  "One branch remains unoccupied. Punch rests there without approaching the feeding troop.",
  "Leaves collected beside Ora make a temporary sleeping place away from the main group.",
  "Cold draws the troop together, leaving Punch to weigh warmth against the risk of approach.",
  "Hana permits a closer approach, but Punch retreats when another macaque turns toward him.",
  "One of Ora’s button eyes is missing. Her familiar texture remains a source of comfort.",
  "Toma feeds nearby without displacing Punch, a small change in the rules Punch expects.",
  "Beneath the cedars, Punch chooses to linger after the rest of the troop moves on.",
  "Sato leaves an open palm visible during a distant encounter and lets Punch set the distance.",
  "Punch recognizes the river path back toward the city but turns toward the calls above him.",
  "A hollow in a cedar offers shelter without the familiar scent of the nursery.",
  "The toy is worn nearly flat; Punch settles it against the bark before sleeping.",
  "Sato records what he saw, not what he wishes Punch had understood.",
];
export const profiles: Record<string, Record<string, string>> = {
  Punch: {
    Personality: "Cautious, curious, persistent, and sensitive to rejection.",
    Backstory:
      "Rejected as an infant, Punch grew up in the nursery with Sato and Ora.",
    "Physical description":
      "A small Japanese macaque with warm brown fur and watchful dark eyes.",
    Goals: "Find shelter and food without losing Ora.",
    Motivations: "Familiar textures and repeated rhythms help him feel safe.",
    Fears: "Kuro’s approach and sudden separation.",
    Weaknesses: "Distrust and limited experience of natural troop dynamics.",
    "Character arc":
      "From solitary vigilance toward a tentative place in a community.",
    "Dialogue notes":
      "Tell his experience through movement, sound, scent, and attention. No human speech.",
  },
  Ora: {
    "Physical description":
      "Faded orange cloth, mismatched button eyes, loose seams, and a repaired arm.",
    Backstory: "Sato placed the toy beside infant Punch in the nursery.",
    "Character arc":
      "A constant touchstone whose physical wear records the journey.",
    "Continuity notes":
      "Track which arm is damaged; Ora is an object, never an independently conscious narrator.",
  },
  Kuro: {
    Personality:
      "Territorial, vigilant, and powerful in the enclosure hierarchy.",
    Motivations: "Maintain access to space and social position.",
    "Physical description": "A broad-shouldered adult male Japanese macaque.",
    Fears: "Loss of social position.",
    "Continuity notes":
      "His fate after the structural collapse is unconfirmed.",
  },
  Sato: {
    Personality:
      "Observant, protective, regretful, and professionally experienced.",
    Backstory: "A night-shift keeper who fed Punch and introduced Ora.",
    Goals: "Find Punch without frightening him further.",
    Motivations: "Affection balanced against the demands of animal welfare.",
    "Character arc":
      "Learn to distinguish caring for Punch from deciding what belongs to him.",
  },
};
