/** @type {import('next').NextConfig} */
const nextConfig = {
  devIndicators: false,
  async headers() { return [{ source: '/:path*', headers: [{ key: 'X-Content-Type-Options', value: 'nosniff' }, { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' }, { key: 'Strict-Transport-Security', value: 'max-age=63072000' }] }] },
  images: {
    unoptimized: true,
  },
}

export default nextConfig
